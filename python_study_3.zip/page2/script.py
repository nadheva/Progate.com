# Definisikan function print_hand 
def print_hand():
    print('Anda memilih: Batu')

# Panggil function print_hand 
print_hand()