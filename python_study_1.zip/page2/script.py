# Cetak 'Hello World'
print ('Hello World')
