fruits = {'apel': 1, 'pisang': 2, 'jeruk': 4}

# Perbarui nilai dengan kunci 'pisang' ke 3
fruits['pisang'] = 3

# Tambahkan element ke fruits dengan kunci 'anggur' dan nilai 5
fruits['anggur'] = 5

# Cetak fruits
print(fruits)
