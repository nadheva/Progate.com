fruits = {'apel': 'apple', 'jeruk': 'orange', 'anggur': 'grape'}

# Dengan loop for, cetak '___ adalah ___ dalam bahasa Inggris'
for kunci_fruit in fruits:
    print(kunci_fruit+" adalah "+fruits[kunci_fruit]+" dalam bahasa Inggris")
